﻿namespace AttendanceBook
{
    internal class Config
    {
        private static string dbPath = System.IO.Directory.GetCurrentDirectory() + "\\Database\\db.accdb;ole db services=-1";
        private static string connectionString = $"provider=microsoft.ace.oledb.12.0;data source={dbPath}";

        internal static string DatabasePath
        {
            get
            {
                return dbPath;
            }
        }

        internal static string ConnectionString
        {
            get
            {
                return connectionString;
            }
        }
    }
}

﻿namespace AttendanceBook
{


    partial class DSet
    {
        partial class tblTempDataTable
        {
        }
    }
}

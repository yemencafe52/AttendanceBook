﻿using ABCoreLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceBook
{
    public partial class FrmAttendanceEntry : Form
    {
        public FrmAttendanceEntry()
        {
            InitializeComponent();
            Preparing();
        }

        private bool Preparing()
        {
            bool res = false;
            comboBox1.ValueMember = "Number";
            comboBox1.DisplayMember = "Name";
            comboBox1.DataSource = ABCoreLib.LevelInfo.GetALL();
            res = true;
            return res;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void Save()
        {
            List<AttendanceInfo> t = new List<AttendanceInfo>();
            DGRows.GetAtnRows(this.dataGridView1, (int)numericUpDown1.Value, dateTimePicker1.Value, ref t);
            AttendanceDocument ad = new AttendanceDocument((int)numericUpDown1.Value, dateTimePicker1.Value, Convert.ToInt32(comboBox1.SelectedValue), t);

            if(!(new ADocumentController(new DSLib.AccessDB(Config.ConnectionString)).New(ad)))
            {
                MessageBox.Show("تعذر تنفيذ العملية");return;
            }

            this.Close();            
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            List<Student> students = new List<Student>();
            new StudentController(new DSLib.AccessDB(Config.ConnectionString)).Read(Convert.ToInt32(comboBox1.SelectedValue),ref students);
            DGRows.InitDG(this.dataGridView1, students);
        }
    }

    class DGRows
    {
        internal static bool InitDG(DataGridView dataGridView,List<Student> students)
        {
            bool res = false;

            dataGridView.Rows.Clear();
            foreach(Student s in students)
            {
                dataGridView.Rows.Add(new object[] { 
                    s.Number
                    ,
                    s.Name
                    ,
                    true });
            }

            res = true;
            return res;
        }

        internal static bool GetAtnRows(DataGridView dataGridView, int docNumber,DateTime date, ref List<AttendanceInfo> attendanceInfos)
        {
            bool res = false;

            try
            {
                for (int i = 0; i < dataGridView.Rows.Count; i++)
                {
                    attendanceInfos.Add(new AttendanceInfo(0, docNumber, int.Parse(dataGridView.Rows[i].Cells[0].Value.ToString()), Convert.ToBoolean(dataGridView.Rows[i].Cells[2].Value.ToString())));
                }

                res = true;
            }
            catch { }

            return res;
        }
    }
}

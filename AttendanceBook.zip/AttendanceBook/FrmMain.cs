﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceBook
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }
        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            TreeNode tn = this.treeView1.SelectedNode;

            if (!(tn is null))
            {
                if(!(tn.Tag is null))
                {
                    switch (byte.Parse(tn.Tag.ToString()))
                    {
                        case 1:
                            {
                                FrmStudentEntry frmStudentEntry = new FrmStudentEntry();
                                frmStudentEntry.ShowDialog();
                                break;
                            }

                        case 2:
                            {
                                FrmStudentsList frmStudentsList = new FrmStudentsList();
                                frmStudentsList.ShowDialog();
                                break;
                            }

                        case 3:
                            {
                                FrmAttendanceEntry frmAttendanceEntry = new FrmAttendanceEntry();
                                frmAttendanceEntry.ShowDialog();
                                break;
                            }

                        case 4:
                            {
                                FrmStudentsReport frmStudentsReport = new FrmStudentsReport();
                                frmStudentsReport.ShowDialog();
                                break;
                            }

                        case 5:
                            {
                                FrmDailyAttendanceReport frmDailyAttendanceReport = new FrmDailyAttendanceReport();
                                frmDailyAttendanceReport.ShowDialog();
                                break;
                            }

                        case 6:
                            {
                                FrmAttendanceReport frmAttendanceReport = new FrmAttendanceReport();
                                frmAttendanceReport.ShowDialog();
                                break;
                            }

                        case 7:
                            {
                                break;
                            }
                    }
                }
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAboutBox frmAboutBox = new FrmAboutBox();
            frmAboutBox.ShowDialog();
        }
    }
}

﻿using ABCoreLib;
using DSLib;
using System.Windows.Forms;

namespace AttendanceBook
{
    public partial class FrmStudentEntry : Form
    {
        public FrmStudentEntry()
        {
            InitializeComponent();
            Preparing();
        }

        private bool Preparing()
        {
            bool res = false;
            comboBox1.ValueMember = "Number";
            comboBox1.DisplayMember = "Name";
            comboBox1.DataSource = ABCoreLib.LevelInfo.GetALL();
            res = true;
            return res;
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                textBox1.Focus(); return;
            }

            if (!(new StudentController(new AccessDB(Config.ConnectionString)).New(new Student((int)numericUpDown1.Value,textBox1.Text,  int.Parse(comboBox1.SelectedValue.ToString())))))
            {
                MessageBox.Show("تعذر تنفيذ العملية");return;
            }

            this.Close();
        }
    }
}

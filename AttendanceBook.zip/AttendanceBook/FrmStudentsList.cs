﻿using ABCoreLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceBook
{
    public partial class FrmStudentsList : Form
    {
        public FrmStudentsList()
        {
            InitializeComponent();
            Preparing();
        }

        private bool Preparing()
        {
            bool res = false;
            Search();
            res = true;
            return res;
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            FrmStudentEntry frmStudentEntry = new FrmStudentEntry();
            frmStudentEntry.ShowDialog();
            toolStripButton2.PerformClick();
        }

        private void Display(List<Student> students)
        {
            this.listView1.Items.Clear();
            toolStripStatusLabel2.Text = "0";

            for (int i = 0; i < students.Count; i++)
            {
                ListViewItem lvi = new ListViewItem(students[i].Number.ToString());
                lvi.SubItems.Add(students[i].Name);
                lvi.SubItems.Add(((Level)students[i].Level).ToString());

                this.listView1.Items.Add(lvi);
            }

            toolStripStatusLabel2.Text = students.Count.ToString();
        }

        private void Search()
        {
            List<Student> students = new List<Student>();
            new StudentController(new DSLib.AccessDB(Config.ConnectionString)).Search(toolStripTextBox1.Text, ref students);
            Display(students);
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Search();
        }
    }
}

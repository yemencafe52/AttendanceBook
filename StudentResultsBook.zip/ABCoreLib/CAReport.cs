﻿using DSLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCoreLib
{
    public class AReport
    {
        private readonly AccessDB accessDB;

        public AReport(AccessDB accessDB)
        {
            this.accessDB = accessDB;
        }

        public bool GetReport1(DateTime from ,DateTime to,ref DataTable dt)
        {
            bool res = false;

            try
            {
                string sql = "SELECT tblAttendanceDocument.adNumber, tblAttendanceDocument.adDate, tblAttendanceDocument.adLevel, tblAttendanceInfo.aiNumber, tblAttendanceInfo.stdNumber, tblStudents.stdNumber AS Expr2, tblStudents.stdName,tblAttendanceInfo.aiPrecent FROM(tblAttendanceDocument INNER JOIN tblAttendanceInfo ON tblAttendanceDocument.adNumber = tblAttendanceInfo.adNumber) INNER JOIN tblStudents ON tblAttendanceInfo.stdNumber = tblStudents.stdNumber";
                if (this.accessDB.ExeuteQuery(sql,ref dt) > 0)
                {
                    res = true;
                }
            }
            catch { }
            return res;
        }

        public bool GetReport1(int levelNumber,DateTime from, DateTime to, ref DataTable dt)
        {
            bool res = false;

            try
            {
                string sql = "SELECT tblAttendanceDocument.adNumber, tblAttendanceDocument.adDate, tblAttendanceDocument.adLevel, tblAttendanceInfo.aiNumber, tblAttendanceInfo.stdNumber, tblStudents.stdNumber AS Expr2, tblStudents.stdName,tblAttendanceInfo.aiPrecent FROM(tblAttendanceDocument INNER JOIN tblAttendanceInfo ON tblAttendanceDocument.adNumber = tblAttendanceInfo.adNumber) INNER JOIN tblStudents ON tblAttendanceInfo.stdNumber = tblStudents.stdNumber";
                if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
                {
                    res = true;
                }
            }
            catch { }
            return res;
        }

        public bool GetReport1(int levelNumber, DateTime from, DateTime to,int stdNumber, ref DataTable dt)
        {
            bool res = false;

            try
            {
                string sql = "SELECT tblAttendanceDocument.adNumber, tblAttendanceDocument.adDate, tblAttendanceDocument.adLevel, tblAttendanceInfo.aiNumber, tblAttendanceInfo.stdNumber, tblStudents.stdNumber AS Expr2, tblStudents.stdName,tblAttendanceInfo.aiPrecent FROM(tblAttendanceDocument INNER JOIN tblAttendanceInfo ON tblAttendanceDocument.adNumber = tblAttendanceInfo.adNumber) INNER JOIN tblStudents ON tblAttendanceInfo.stdNumber = tblStudents.stdNumber";
                if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
                {
                    res = true;
                }
            }
            catch { }
            return res;
        }

        public bool GetReport2(DateTime from, DateTime to, ref DataTable dt)
        {
            bool res = false;

            try
            {
                string sql = "SELECT tblAttendanceDocument.adNumber, tblAttendanceDocument.adDate, tblAttendanceDocument.adLevel, tblAttendanceInfo.aiNumber, tblAttendanceInfo.stdNumber, tblStudents.stdNumber AS Expr2, tblStudents.stdName,tblAttendanceInfo.aiPrecent FROM(tblAttendanceDocument INNER JOIN tblAttendanceInfo ON tblAttendanceDocument.adNumber = tblAttendanceInfo.adNumber) INNER JOIN tblStudents ON tblAttendanceInfo.stdNumber = tblStudents.stdNumber";
                if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
                {
                    res = true;
                }
            }
            catch { }
            return res;
        }

        public bool GetReport2(int levelNumber, DateTime from, DateTime to, ref DataTable dt)
        {
            bool res = false;

            try
            {
                string sql = "";
                if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
                {
                    res = true;
                }
            }
            catch { }
            return res;
        }

        public bool GetReport3(int levelNumber, DateTime from, DateTime to, int stdNumber, ref DataTable dt)
        {
            bool res = false;

            try
            {
                string sql = "";
                if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
                {
                    res = true;
                }
            }
            catch { }
            return res;
        }

    }
}

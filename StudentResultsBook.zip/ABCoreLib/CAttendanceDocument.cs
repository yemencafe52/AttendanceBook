﻿using DSLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCoreLib
{
    public class AttendanceDocument
    {
        private int adNumber;
        private DateTime adDate;
        private int stdLevel;
        private List<AttendanceInfo> t = new List<AttendanceInfo>();
        public AttendanceDocument(
             int adNumber,
             DateTime adDate,
             int stdLevel,
             List<AttendanceInfo> t
            )
        {
            this.adNumber = adNumber;
            this.adDate = adDate;
            this.stdLevel = stdLevel;
            this.t.AddRange(t.ToArray());
        }

        public int ANNumber
        {
            get
            {
                return this.adNumber;
            }
        }

        public DateTime Date
        {
            get
            {
                return this.adDate;
            }
        }

        public int Level
        {
            get
            {
                return this.stdLevel;
            }
        }

        public List<AttendanceInfo> ARecords
        {
            get
            {
                return this.t;
            }
        }
    }

    public class ADocumentController
    {
        private readonly AccessDB accessDB;
        public ADocumentController(AccessDB accessDB)
        {
            this.accessDB = accessDB;
        }
        public bool New(AttendanceDocument attendanceDocument)
        {
            bool res = false;
            string sql = string.Format("insert into tblAttendanceDocument " +
                "(" +
                    "adNumber" +
                    "," +
                    "adDate" +
                    "," +
                    "adLevel" +
                ")" +
                " " +
                "values" +
                "(" +
                    "{0}" +
                    "," +
                    "'{1}'" +
                    "," +
                    "{2}" +
                ")", new object[] {
                    attendanceDocument.ANNumber
                    ,
                    attendanceDocument.Date.ToString("yyyy/MM/dd")
                    ,
                    attendanceDocument.Level
                }
            );

            if (this.accessDB.ExecuteNoneQuery(sql) > 0)
            {
                for (int i = 0; i < attendanceDocument.ARecords.Count; i++)
                {
                    if(!(new AttendanceController(this.accessDB).New(attendanceDocument.ARecords[i])))
                    {
                        // delete document;
                        return res;
                    }
                }

                res = true;
            }

            return res;
        }

        public bool Read(int number, out AttendanceDocument attendanceDocument)
        {
            bool res = false;
            attendanceDocument = null;

            string sql = $"select adNumber,adDate,adLevel from tblAttendanceDocument where adNumber={number}";
            DataTable dt = new DataTable();

            if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
            {
                List<AttendanceInfo> t = new List<AttendanceInfo>();
                if (new AttendanceController(this.accessDB).Read(number, ref t))
                {
                    attendanceDocument = new AttendanceDocument(
                            Convert.ToInt32(dt.Rows[0][0])
                            ,
                            Convert.ToDateTime(dt.Rows[0][1])
                            ,
                            Convert.ToInt32(dt.Rows[0][2])
                            ,
                            t
                            );
                }

                res = true;
            }
            return res;
        }
    }
}

﻿using DSLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCoreLib
{
    public class AttendanceInfo
    {
        private int aiNumber;
        private int adNumber;
        private int stdNumber;
        private bool aiPrecent;
        public AttendanceInfo(
          int aiNumber,
          int adNumber,
          int stdNumber,
          bool aiPrecent

            )
        {
            this.aiNumber = aiNumber;
            this.adNumber = adNumber;
            this.stdNumber = stdNumber;
            this.aiPrecent = aiPrecent;
        }

        public int AINumber
        {
            get
            {
                return this.aiNumber;
            }
        }

        public int DocumentNumber
        {
            get
            {
                return this.adNumber;
            }
        }

        public int StudentNumber
        {
            get
            {
                return this.stdNumber;
            }
        }

        public bool IsPresent
        {
            get
            {
                return this.aiPrecent;
            }
        }
    }

    public class AttendanceController
    {
        private readonly AccessDB accessDB;

        public AttendanceController(AccessDB accessDB)
        {
            this.accessDB = accessDB;
        }

        public bool New(AttendanceInfo attendanceInfo)
        {
            bool res = false;
            string sql = string.Format("insert into tblAttendanceInfo " +
                "(" +
               //     "aiNumber" +
               //     "," +
                    "adNumber" +
                    "," +
                    "stdNumber" +
                    ",a" +
                    "iPrecent" +
                ")" +
                " " +
                "values" +
                "(" +
                    "{0}" +
                    "," +
                    "{1}" +
                    "," +
                    "{2}" +
             //       "," +
             //       "{3}" +
                ")", new object[]
                { 
              //      attendanceInfo.AINumber
              //      ,
                    attendanceInfo.DocumentNumber
                    ,
                    attendanceInfo.StudentNumber
                    ,
                    attendanceInfo.IsPresent
                });

            res = this.accessDB.ExecuteNoneQuery(sql) > 0 ? true : false;
            return res;
        }

        public bool Read(int number, ref List<AttendanceInfo> t)
        {
            bool res = false;

            string sql = $"select aiNumber,adNumber,stdNumber,aiPrecent from tblAttendanceInfo where adNumber={number}";
            DataTable dt = new DataTable();
            if(this.accessDB.ExeuteQuery(sql,ref dt) > 0)
            {
                for(int i = 0; i < dt.Rows.Count; i++)
                {
                    t.Add(new AttendanceInfo(
                        Convert.ToInt32(dt.Rows[i][0])
                        ,
                        Convert.ToInt32(dt.Rows[i][1])
                        ,
                        Convert.ToInt32(dt.Rows[i][2])
                        ,
                        Convert.ToBoolean(dt.Rows[i][3])
                        ));
                }

                res = t.Count > 0 ? true : false;
            }

            return res;
        }
    }
}

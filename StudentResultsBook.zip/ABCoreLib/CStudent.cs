﻿using DSLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCoreLib
{
    public class Student
    {
        private int stdNumber;
        private string stdName;
        private int stdLevel;

        public Student(
             int stdNumber,
             string stdName,
             int stdLevel   
            ) {
            this.stdNumber = stdNumber;
            this.stdName = stdName;
            this.stdLevel = stdLevel;
        }

        public int Number
        {
            get
            {
                return this.stdNumber;
            }
        }

        public string Name
        {
            get
            {
                return this.stdName;
            }
        }

        public int Level
        {
            get
            {
                return this.stdLevel;
            }
        }
    }

    public class StudentController
    {
        private readonly AccessDB accessDB;

        public StudentController(AccessDB accessDB)
        {
            this.accessDB = accessDB;
        }

        public bool New(Student student)
        {
            bool res = false;
            string sql = string.Format("insert into tblStudents " +
                "(" +
                    "stdNumber" +
                    "," +
                    "stdName" +
                    "," +
                    "stdLevel" +
                ")" +
                " " +
                "values" +
                "(" +
                    "{0}" +
                    "," +
                    "'{1}'" +
                    "," +
                    "{2}" +
                ")", new object[]
                {
                    student.Number
                    ,
                    student.Name
                    ,
                    student.Level
                });

            res = this.accessDB.ExecuteNoneQuery(sql) > 0 ? true : false;
            return res;
        }

        public bool Read(int number,List<Student> students)
        {
            bool res = false;

            string sql = $"select stdNumber,stdName,stdLevel from tblStudents stdNumber={number}";
            DataTable dt = new DataTable();
            if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
            {
                //for (int i = 0; i < dt.Rows.Count; i++)
                //{
                //    students.Add(
                        new Student(
                        Convert.ToInt32(dt.Rows[0][0])
                        ,
                        Convert.ToString(dt.Rows[0][1])
                        ,
                        Convert.ToInt32(dt.Rows[0][2])
                    //    )
                    );
               // }

                res = students.Count > 0 ? true : false;
            }

            return res;
        }

        public bool Search(string txt,ref List<Student> students)
        {
            bool res = false;

            students.Clear();
            string sql = $"select stdNumber,stdName,stdLevel from tblStudents where stdName like('%{txt}%')";
            DataTable dt = new DataTable();

            if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    students.Add(new Student(
                        Convert.ToInt32(dt.Rows[i][0])
                        ,
                        Convert.ToString(dt.Rows[i][1])
                        ,
                        Convert.ToInt32(dt.Rows[i][2])
                        ));


                }

                res = students.Count > 0 ? true : false;
            }

            return res;

        }

        public bool Read(int level, ref List<Student> students)
        {
            bool res = false;

            students.Clear();
            string sql = $"select stdNumber,stdName,stdLevel from tblStudents where stdLevel={level}";
            DataTable dt = new DataTable();

            if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    students.Add(new Student(
                        Convert.ToInt32(dt.Rows[i][0])
                        ,
                        Convert.ToString(dt.Rows[i][1])
                        ,
                        Convert.ToInt32(dt.Rows[i][2])
                        ));


                }

                res = students.Count > 0 ? true : false;
            }

            return res;

        }
    }
}

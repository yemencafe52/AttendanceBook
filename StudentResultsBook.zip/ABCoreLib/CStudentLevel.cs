﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCoreLib
{
    public enum Level : byte
    {
        الأول =1,
        الثاني,
        الثالث,
        الرابع,
        الخامس,
        السادس,
        السابع,
        الثامن,
        التاسع,
        العاشر,
        الحادي_عشر,
        الثاني_عشر
    }

    public class LevelInfo
    {
        private byte number;
        private string name;

        public LevelInfo(
            byte number,
            string name)
        {
            this.number = number;
            this.name = name;
        }

        public byte Number
        {
            get { return this.number; }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public static List<LevelInfo> GetALL()
        {
            List<LevelInfo> res = new List<LevelInfo>();
            
            for(byte i = 0; i < 12; i++)
            {
                res.Add(new LevelInfo((byte)(i +1), Convert.ToString(((Level)i + 1))));
            }
            
            return res;
        }
    }
}

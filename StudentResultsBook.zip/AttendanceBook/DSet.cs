﻿namespace AttendanceBook
{


    partial class DSet
    {
        partial class tblResultsDataTable
        {
        }

        partial class tblTempDataTable
        {
        }
    }
}

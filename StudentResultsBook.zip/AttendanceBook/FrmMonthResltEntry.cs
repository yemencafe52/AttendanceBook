﻿using ABCoreLib;
using MonthResultsCoreLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AttendanceBook
{
    public partial class FrmMonthResltEntry : Form
    {
        public FrmMonthResltEntry()
        {
            InitializeComponent();
            Preparing();
        }

        private bool Preparing()
        {
            bool res = false;
            comboBox1.ValueMember = "Number";
            comboBox1.DisplayMember = "Name";
            comboBox1.DataSource = ABCoreLib.LevelInfo.GetALL();

            comboBox2.ValueMember = "Number";
            comboBox2.DisplayMember = "Name";
            comboBox2.DataSource = MonthResultsCoreLib.SubjectInfo.GetALL(1);

            res = true;
            return res;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void Save()
        {
            List<MonthResultsCoreLib.ResultDetials> t = new List<ResultDetials>();
            DGRows0.GetRows(this.dataGridView1, (int)numericUpDown1.Value, ref t);
            MonthResultsCoreLib.SubjectDocument ad = new SubjectDocument((int)numericUpDown1.Value, Convert.ToInt32(comboBox1.SelectedValue), dateTimePicker1.Value, Convert.ToInt32(comboBox2.SelectedValue), t);

            if(!(new SubjectDocumentController(new DSLib.AccessDB(Config.ConnectionString)).New(ad)))
            {
                MessageBox.Show("تعذر تنفيذ العملية");return;
            }

            this.Close();            
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            List<Student> students = new List<Student>();
            new StudentController(new DSLib.AccessDB(Config.ConnectionString)).Read(Convert.ToInt32(comboBox1.SelectedValue),ref students);
            DGRows0.InitDG(this.dataGridView1, students);
        }

       
    }

    class DGRows0
    {
        internal static bool InitDG(DataGridView dataGridView,List<Student> students)
        {
            bool res = false;

            dataGridView.Rows.Clear();
            foreach(Student s in students)
            {
                
                dataGridView.Rows.Add(new object[] { 
                    s.Number
                    ,
                    s.Name
                    ,
                    0
                    ,
                    0
                    ,
                    0
                    ,
                    0
                    ,
                    0
                    ,
                    0
                });
            }

            res = true;
            return res;
        }

        internal static bool GetRows(DataGridView dataGridView, int docNumber, ref List<ResultDetials> resultDetials)
        {
            bool res = false;

            try
            {
                for (int i = 0; i < dataGridView.Rows.Count; i++)
                {
                    resultDetials.Add(new ResultDetials(
                        0
                        ,
                        docNumber
                        ,
                        int.Parse(dataGridView.Rows[i].Cells[0].Value.ToString())
                        ,
                        0
                        ,
                        double.Parse(dataGridView.Rows[i].Cells[2].Value.ToString())
                        ,
                        double.Parse(dataGridView.Rows[i].Cells[3].Value.ToString())
                        ,
                        double.Parse(dataGridView.Rows[i].Cells[4].Value.ToString())
                        ,
                        double.Parse(dataGridView.Rows[i].Cells[5].Value.ToString())
                        ,
                        double.Parse(dataGridView.Rows[i].Cells[6].Value.ToString())
                        ));
                }

                res = true;
            }
            catch { }

            return res;
        }
    }
}

﻿using ABCoreLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using MonthResultsCoreLib;

namespace AttendanceBook
{
    public partial class FrmMonthResultReport : Form
    {
        public FrmMonthResultReport()
        {
            InitializeComponent();
            Prepring();
        }

        private bool Prepring()
        {
            bool res = false;

            comboBox2.SelectedIndex = 0;
            res = true;
            return res;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            switch (comboBox2.SelectedIndex)
            {
                case 0:
                    {
                        //RptMonthResult1

                        DataTable dt = new DSet.tblResultsDataTable();
                        new MReport(new DSLib.AccessDB(Config.ConnectionString)).GetReport1(dateTimePicker1.Value, dateTimePicker1.Value, ref dt);

                        ReportDataSource rpt = new ReportDataSource("tblResults", dt);
                        FrmReportViewer frmReportViewer = new FrmReportViewer(rpt, "AttendanceBook.RptMonthResult1.rdlc");
                        frmReportViewer.ShowDialog();
                        break;

                        
                    }

                    case 1:
                    {
                        DataTable dt = new DSet.tblResultsDataTable();
                        new MReport(new DSLib.AccessDB(Config.ConnectionString)).GetReport1(dateTimePicker1.Value, dateTimePicker1.Value, ref dt);

                        ReportDataSource rpt = new ReportDataSource("tblResults", dt);
                        FrmReportViewer frmReportViewer = new FrmReportViewer(rpt, "AttendanceBook.RptTotalMonthResult.rdlc");
                        frmReportViewer.ShowDialog();
                        break;
                    }
                default:
                    break;
            }
           
        }
    }
}

﻿using DSLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonthResultsCoreLib
{
    public class MReport
    {
        private readonly AccessDB accessDB;

        public MReport(AccessDB accessDB)
        {
            this.accessDB = accessDB;
        }

        public bool GetReport1(DateTime from ,DateTime to,ref DataTable dt)
        {
            bool res = false;

            try
            {
                string sql = "SELECT tblMonthResultDocument.mrNumber, tblMonthResultDocument.mrDate, tblMonthResultDocument.stdLevel, tblMonthResultDocument.subNumber, tblMonthResultDetails.mrdNumber, tblMonthResultDetails.mrNumber AS Expr1, tblMonthResultDetails.stdNumber, tblMonthResultDetails.mrdAtten, tblMonthResultDetails.mrdActivites, tblMonthResultDetails.mrdHomework, tblMonthResultDetails.mrdQuez1, tblMonthResultDetails.mrdQuez2, tblMonthResultDetails.mrdTotal, tblStudents.stdNumber AS Expr2, tblStudents.stdName, tblStudents.stdLevel AS Expr3 FROM(tblMonthResultDocument INNER JOIN tblMonthResultDetails ON tblMonthResultDocument.mrNumber = tblMonthResultDetails.mrNumber) INNER JOIN tblStudents ON tblMonthResultDetails.stdNumber = tblStudents.stdNumber";
                if (this.accessDB.ExeuteQuery(sql,ref dt) > 0)
                {
                    res = true;
                }
            }
            catch { }
            return res;
        }

    }
}

﻿using DSLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonthResultsCoreLib
{
    public class ResultDetials
    {
        private int rdNumber;
        private int mrNumber;
        private int stdNumber;
        private double rdAttent;
        private double rdActivites;
        private double rdHomework;
        private double rdQuez;
        private double rdQuez2;
        private double rdTotal;

        public ResultDetials(int rdNumber,int mrNumber, int stdNumber, double rdAttent, double rdActivites, double rdHomework, double rdQuez, double rdQuez2, double rdTotal)
        {
            this.rdNumber = rdNumber;
            this.mrNumber = mrNumber;
            this.stdNumber = stdNumber;
            this.rdAttent = rdAttent;
            this.rdActivites = rdActivites;
            this.rdHomework = rdHomework;
            this.rdQuez = rdQuez;
            this.rdQuez2 = rdQuez2;
            this.rdTotal = rdTotal;
        }

        public int RdNumber { get => rdNumber; }
        public int MrdNumber { get => mrNumber;  }
        public int StdNumber { get => stdNumber;  }
        public double RdAttent { get => rdAttent;  }
        public double RdActivites { get => rdActivites; }
        public double RdHomework { get => rdHomework; }
        public double RdQuez { get => rdQuez;  }
        public double RdQuez2 { get => rdQuez2; }
        public double RdTotal { get => rdTotal; }
    }

    public class ResultDetialsController
    {
        private readonly DSLib.AccessDB accessDB;

        public ResultDetialsController(AccessDB accessDB)
        {
            this.accessDB = accessDB;
        }

        public bool New(ResultDetials resultDetials)
        {
            bool res = false;
            string sql = string.Format("insert into tblMonthResultDetails " +
                "(" +
                    //     "mrdNumber" +
                    //     "," +
                    "mrNumber" +
                    "," +
                    "stdNumber" +
                    "," +
                    "mrdAtten" +
                    "," +
                    "mrdActivites" +
                    "," +
                    "mrdHomework" +
                    "," +
                    "mrdQuez1" +
                    "," +
                    "mrdQuez2" +
                    "," +
                    "mrdTotal" +
                ")" +
                " " +
                "values" +
                "(" +
                    "{0}" +
                    "," +
                    "{1}" +
                    "," +
                    "{2}" +
                    "," +
                    "{3}" +
                    "," +
                    "{4}" +
                    "," +
                    "{5}" +
                    "," +
                    "{6}" +
                    "," +
                    "{7}" +
                ")", new object[]
                {
                    resultDetials.MrdNumber,
                    resultDetials.StdNumber,
                    resultDetials.RdAttent,
                    resultDetials.RdActivites,
                    resultDetials.RdHomework,
                    resultDetials.RdQuez,
                    resultDetials.RdQuez2,
                    resultDetials.RdTotal

                });

            res = this.accessDB.ExecuteNoneQuery(sql) > 0 ? true : false;
            return res;
        }

        public bool Read(int number, ref List<ResultDetials> t)
        {
            bool res = false;

            string sql = $"select mrdNumber,mrNumber,stdNumber,mrdAtten,mrdActivites,mrdHomework,mrdQuez1,mrdQuez2,mrdTotal from tblMonthResultDetails where mrNumber={number}";
            DataTable dt = new DataTable();
            if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    t.Add(new ResultDetials(
                        Convert.ToInt32(dt.Rows[i][0])
                        ,
                        Convert.ToInt32(dt.Rows[i][1])
                        ,
                        Convert.ToInt32(dt.Rows[i][2])
                        ,
                        Convert.ToDouble(dt.Rows[i][3])
                        ,
                        Convert.ToDouble(dt.Rows[i][4])
                        ,
                        Convert.ToDouble(dt.Rows[i][5])
                        ,
                        Convert.ToDouble(dt.Rows[i][6])
                        ,
                        Convert.ToDouble(dt.Rows[i][7])
                        ,
                        Convert.ToDouble(dt.Rows[i][8])
                        ));
                }

                res = t.Count > 0 ? true : false;
            }

            return res;
        }
    }
}

﻿using DSLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonthResultsCoreLib
{
    public class SubjectDocument
    {
        private int sdNumber;
        private int stdLevel;
        private DateTime date;
        private int subNumber;
        private List<ResultDetials> t = new List<ResultDetials>();

        public SubjectDocument(int sdNumber, int stdLevel, DateTime date, int subNumber,List<ResultDetials> t)
        {
            this.sdNumber = sdNumber;
            this.stdLevel = stdLevel;
            this.date = date;
            this.subNumber = subNumber;
            this.t = t;
        }

        public int SdNumber { get => sdNumber; set => sdNumber = value; }
        public int StdLevel { get => stdLevel; set => stdLevel = value; }
        public int SubNumber { get => subNumber; set => subNumber = value; }
        public DateTime Date { get => date; set => date = value; }
        public List<ResultDetials> SRecords { get => this.t; }
    }
    public class SubjectDocumentController
    {
        private readonly AccessDB accessDB;
        public SubjectDocumentController(AccessDB accessDB)
        {
            this.accessDB = accessDB;
        }
        public bool New(SubjectDocument subjectDocument)
        {
            bool res = false;
            string sql = string.Format("insert into tblMonthResultDocument " +
                "(" +
                    "mrNumber" +
                    "," +
                    "mrDate" +
                    "," +
                    "stdLevel" +
                    "," +
                    "subNumber" +
                ")" +
                " " +
                "values" +
                "(" +
                    "{0}" +
                    "," +
                    "'{1}'" +
                    "," +
                    "{2}" +
                    "," +
                    "{3}" +
                ")", new object[] {
                    subjectDocument.SdNumber
                    ,
                    subjectDocument.Date.ToString("yyyy/MM/dd")
                    ,
                    subjectDocument.StdLevel
                    ,
                    subjectDocument.SubNumber
                }
            );

            if (subjectDocument.SRecords.Count > 0)
            {
                if (this.accessDB.ExecuteNoneQuery(sql) > 0)
                {
                    for (int i = 0; i < subjectDocument.SRecords.Count; i++)
                    {
                        if (!(new ResultDetialsController(this.accessDB).New(subjectDocument.SRecords[i])))
                        {
                            // delete document;
                            return res;
                        }
                    }

                    res = true;
                }
            }

            return res;
        }

        public bool Read(int number, out MonthResultsCoreLib.SubjectDocument subjectDocument)
        {
            bool res = false;
            subjectDocument = null;

            string sql = $"select mrNumber,mrDate,stdLevel,subNumber tblMonthResultDocument where mrNumber={number}";
            DataTable dt = new DataTable();

            if (this.accessDB.ExeuteQuery(sql, ref dt) > 0)
            {
                List<ResultDetials> t = new List<ResultDetials>();
                if (new ResultDetialsController(this.accessDB).Read(number, ref t))
                {
                    subjectDocument = new SubjectDocument(
                            Convert.ToInt32(dt.Rows[0][0])
                            ,
                            Convert.ToInt32(dt.Rows[0][1])
                            ,
                            Convert.ToDateTime(dt.Rows[0][2])
                            ,
                            Convert.ToInt32(dt.Rows[0][4])
                            ,
                            t
                            );
                }

                res = true;
            }
            return res;
        }
    }
}

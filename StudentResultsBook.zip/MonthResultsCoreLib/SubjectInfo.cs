﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonthResultsCoreLib
{
    public enum Subject : byte
    {
        قرآن = 1,
        إسلامية,
        عربي,
        رياضيات,
        علوم
    }

    public class SubjectInfo
    {
        private byte number;
        private string name;

        public SubjectInfo(
            byte number,
            string name)
        {
            this.number = number;
            this.name = name;
        }

        public byte Number
        {
            get { return this.number; }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public static List<SubjectInfo> GetALL(int level)
        {
            List<SubjectInfo> res = new List<SubjectInfo>();

            for (byte i = 0; i < 5; i++)
            {
                res.Add(new SubjectInfo((byte)(i + 1), Convert.ToString(((Subject)i + 1))));
            }

            return res;
        }

        public string GetSubName(int subNumber)
        {
            string res = "test";
            return res;
        }
    }
}
